package Pages;

import com.intuit.karate.Json;

public class Demojavawrite {
    public static String name;
    public static void writeFile( String obj){
        name=obj;

    }
    public static String readvar(){
        return name;

    }
    public static Json requestBody(String add){
        Json json= new Json("{ \"place_id\":"+ name + ",\"address\":" +add + ", \"key\":\"qaclick123\" }");
        System.out.println(json);
        return json;
    }
}
